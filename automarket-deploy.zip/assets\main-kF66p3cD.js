(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))n(i);new MutationObserver(i=>{for(const a of i)if(a.type==="childList")for(const c of a.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&n(c)}).observe(document,{childList:!0,subtree:!0});function o(i){const a={};return i.integrity&&(a.integrity=i.integrity),i.referrerPolicy&&(a.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?a.credentials="include":i.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function n(i){if(i.ep)return;i.ep=!0;const a=o(i);fetch(i.href,a)}})();const x={apiKey:"AIzaSyBDD4fjIFgwm2F0jBmmQgyGjZsH0UYIYu4",authDomain:"automarket-pro.firebaseapp.com",projectId:"automarket-pro",storageBucket:"automarket-pro.firebasestorage.app",messagingSenderId:"774835684971",appId:"1:774835684971:web:594a1d583731cd6748932e"};firebase.initializeApp(x);firebase.auth();firebase.firestore();firebase.storage();let v=null,d=[],g=!1;const w=document.getElementById("loading"),S=document.getElementById("main-app"),M=document.querySelectorAll(".nav-btn"),N=document.querySelectorAll(".section");document.addEventListener("DOMContentLoaded",async()=>{try{H(),auth.onAuthStateChanged(t=>{v=t,g=!!t,_(),W()}),await G(),h(),F(),z(),ae(),se(),Ee(),setTimeout(()=>{O()},2e3)}catch(t){console.error("Error initializing app:",t),l("Error al cargar la aplicación")}});function H(){w&&(w.style.display="flex")}function O(){w&&(w.style.display="none"),S&&(S.style.display="block")}function F(){M.forEach(t=>{t.addEventListener("click",()=>{const e=t.getAttribute("data-section");u(e)})})}function u(t){N.forEach(n=>{n.classList.remove("active")}),M.forEach(n=>{n.classList.remove("active")});const e=document.getElementById(`${t}-section`);e&&e.classList.add("active");const o=document.querySelector(`[data-section="${t}"]`);o&&o.classList.add("active"),T()}async function G(){try{const e=await db.collection("vehicles").where("status","==","active").orderBy("createdAt","desc").limit(20).get();d=[],e.forEach(o=>{d.push({id:o.id,...o.data()})}),j(),console.log(`Loaded ${d.length} vehicles`)}catch(t){console.error("Error loading vehicles:",t),l("Error al cargar vehículos")}}function j(){const t=document.getElementById("vehicles-list");if(t){if(d.length===0){t.innerHTML=`
            <div class="no-vehicles">
                <p>No hay vehículos disponibles en este momento.</p>
            </div>
        `;return}t.innerHTML=d.map(e=>`
        <div class="vehicle-card" onclick="viewVehicle('${e.id}')">
            <img src="${e.imageUrl||"/512X512.jpc.jpg"}" alt="${e.title}" class="vehicle-image">
            <div class="vehicle-info">
                <h3 class="vehicle-title">${e.title}</h3>
                <p class="vehicle-details">${e.brand} ${e.model} • ${e.year}</p>
                <p class="vehicle-details">${e.location}</p>
                <div class="vehicle-price">$${e.price.toLocaleString()} ${e.currency}</div>
            </div>
        </div>
    `).join("")}}function z(){const t=document.getElementById("login-form");t&&t.addEventListener("submit",D);const e=document.getElementById("register-form");e&&e.addEventListener("submit",U)}function W(){document.querySelector('[data-section="home"]');const t=document.querySelector('[data-section="explore"]'),e=document.querySelector('[data-section="publish"]'),o=document.querySelector('[data-section="profile"]');g?(t&&(t.style.display="flex"),e&&(e.style.display="flex"),o&&(o.style.display="flex")):(t&&(t.style.display="none"),e&&(e.style.display="none"),o&&(o.style.display="none"))}async function D(t){t.preventDefault();const e=new FormData(t.target),o=e.get("email"),n=e.get("password");try{await auth.signInWithEmailAndPassword(o,n),m("¡Bienvenido a AutoMarket!"),u("home")}catch(i){console.error("Login error:",i),l("Error al iniciar sesión. Verificá tu email y contraseña.")}}async function U(t){t.preventDefault();const e=new FormData(t.target),o=e.get("fullName"),n=e.get("email"),i=e.get("password"),a=e.get("country");if(!e.get("terms")){l("Debés aceptar los términos y condiciones");return}try{const s=(await auth.createUserWithEmailAndPassword(n,i)).user;await db.collection("users").add({uid:s.uid,displayName:o,email:n,country:a,isVerifiedPayment:!0,paymentDate:new Date,paymentAmount:2,paymentCurrency:"USD",createdAt:new Date}),m("¡Cuenta creada exitosamente! Pago simulado de $2 USD procesado."),u("home")}catch(p){console.error("Registration error:",p),p.code==="auth/email-already-in-use"?(l("Este email ya está registrado. ¿Querés iniciar sesión?"),setTimeout(()=>{u("login");const s=document.querySelector('#login-section input[name="email"]');s&&(s.value=n)},2e3)):l("Error al crear la cuenta. Intentá nuevamente.")}}function R(){u("login")}function I(){u("register")}function X(){u("terms")}function Y(){const t=document.querySelector('input[name="terms"]');t&&(t.checked=!0),I()}function Q(){const t=document.getElementById("mobile-menu"),e=document.querySelector(".hamburger-menu");t&&t.classList.toggle("active"),e&&e.classList.toggle("active")}function T(){const t=document.getElementById("mobile-menu"),e=document.querySelector(".hamburger-menu");t&&t.classList.remove("active"),e&&e.classList.remove("active")}function _(){v?(console.log("User logged in:",v.email),C(),B()):(console.log("User logged out"),C(),B())}function C(){const t=document.getElementById("explore-section");t&&(g?t.innerHTML=`
                <div class="section-header">
                    <h2>Buscar Vehículos</h2>
                    <div class="filters">
                        <select id="vehicle-type" class="filter-select">
                            <option value="">Tipo de Vehículo</option>
                            <option value="auto">Autos</option>
                            <option value="moto">Motos</option>
                            <option value="pickup">Pickups</option>
                            <option value="comercial">Comerciales</option>
                        </select>
                        <select id="brand" class="filter-select">
                            <option value="">Marca</option>
                            <option value="Nissan">Nissan</option>
                            <option value="Toyota">Toyota</option>
                            <option value="Volkswagen">Volkswagen</option>
                            <option value="Chevrolet">Chevrolet</option>
                            <option value="Ford">Ford</option>
                            <option value="Honda">Honda</option>
                            <option value="Hyundai">Hyundai</option>
                            <option value="Kia">Kia</option>
                            <option value="Mazda">Mazda</option>
                            <option value="Renault">Renault</option>
                            <option value="Peugeot">Peugeot</option>
                            <option value="Fiat">Fiat</option>
                            <option value="Jeep">Jeep</option>
                            <option value="BMW">BMW</option>
                            <option value="Mercedes-Benz">Mercedes-Benz</option>
                            <option value="Audi">Audi</option>
                        </select>
                        <select id="country" class="filter-select">
                            <option value="">País</option>
                            <option value="MX">México</option>
                            <option value="AR">Argentina</option>
                            <option value="CO">Colombia</option>
                            <option value="BR">Brasil</option>
                            <option value="CL">Chile</option>
                            <option value="PE">Perú</option>
                            <option value="UY">Uruguay</option>
                            <option value="PY">Paraguay</option>
                            <option value="BO">Bolivia</option>
                            <option value="EC">Ecuador</option>
                            <option value="VE">Venezuela</option>
                            <option value="GT">Guatemala</option>
                            <option value="HN">Honduras</option>
                            <option value="SV">El Salvador</option>
                            <option value="NI">Nicaragua</option>
                            <option value="CR">Costa Rica</option>
                            <option value="PA">Panamá</option>
                            <option value="CU">Cuba</option>
                            <option value="DO">República Dominicana</option>
                            <option value="PR">Puerto Rico</option>
                        </select>
                    </div>
                </div>
                <div id="vehicles-list" class="vehicles-list">
                    <!-- Vehicles will be loaded here -->
                </div>
            `:t.innerHTML=`
                <div class="auth-required">
                    <div class="auth-required-icon">🔒</div>
                    <h3>Acceso Requerido</h3>
                    <p>Necesitás iniciar sesión para buscar vehículos</p>
                    <button class="btn btn-primary" onclick="showLogin()">Iniciar Sesión</button>
                    <button class="btn btn-secondary" onclick="showRegister()">Crear Cuenta</button>
                </div>
            `);const e=document.getElementById("publish-section");e&&(g?e.innerHTML=`
                <div class="section-header">
                    <h2>Publicar Vehículo</h2>
                    <p>Completa la información de tu vehículo</p>
                </div>
                <div id="publish-form" class="publish-form">
                    <!-- Form will be loaded here -->
                </div>
            `:e.innerHTML=`
                <div class="auth-required">
                    <div class="auth-required-icon">📝</div>
                    <h3>Acceso Requerido</h3>
                    <p>Necesitás iniciar sesión para publicar vehículos</p>
                    <button class="btn btn-primary" onclick="showLogin()">Iniciar Sesión</button>
                    <button class="btn btn-secondary" onclick="showRegister()">Crear Cuenta</button>
                </div>
            `)}function B(){const t=document.getElementById("profile-section");t&&(g?t.innerHTML=`
            <div class="profile-content">
                <div class="profile-header">
                    <div class="profile-avatar">👤</div>
                    <h2>Mi Perfil</h2>
                    <p>${v.email}</p>
                </div>
                <div class="profile-info">
                    <div class="profile-item">
                        <strong>Email:</strong>
                        <span>${v.email}</span>
                    </div>
                    <div class="profile-item">
                        <strong>Estado:</strong>
                        <span>Verificado</span>
                    </div>
                    <div class="profile-item">
                        <strong>Pago:</strong>
                        <span>$2 USD procesado</span>
                    </div>
                </div>
                <button class="btn btn-secondary" onclick="handleSignOut()">Cerrar Sesión</button>
            </div>
        `:t.innerHTML=`
            <div class="auth-required">
                <div class="auth-required-icon">👤</div>
                <h3>Acceso Requerido</h3>
                <p>Necesitás iniciar sesión para ver tu perfil</p>
                <button class="btn btn-primary" onclick="showLogin()">Iniciar Sesión</button>
                <button class="btn btn-secondary" onclick="showRegister()">Crear Cuenta</button>
            </div>
        `)}function m(t){alert("✅ "+t)}function l(t){alert("❌ "+t)}function K(){auth.signOut().then(()=>{m("Sesión cerrada correctamente"),u("home")}).catch(t=>{console.error("Sign out error:",t),l("Error al cerrar sesión")})}function J(){const t=document.getElementById("advanced-filters");t.style.display==="none"?t.style.display="block":t.style.display="none"}function Z(t){const e=d.find(n=>n.id===t);if(!e)return;const o=document.getElementById("vehicle-detail-content");o.innerHTML=`
        <div class="vehicle-gallery">
            <img src="${e.imageUrl||"/512X512.jpc.jpg"}" alt="${e.title}" class="main-image">
        </div>
        
        <div class="vehicle-info-detail">
            <h3>${e.title}</h3>
            <div class="vehicle-price-large">$${e.price.toLocaleString()} ${e.currency}</div>
            
            <div class="vehicle-specs">
                <div class="spec-item">
                    <strong>Marca:</strong> ${e.brand}
                </div>
                <div class="spec-item">
                    <strong>Modelo:</strong> ${e.model}
                </div>
                <div class="spec-item">
                    <strong>Año:</strong> ${e.year}
                </div>
                <div class="spec-item">
                    <strong>Kilometraje:</strong> ${e.mileage||"No especificado"} km
                </div>
                <div class="spec-item">
                    <strong>Ubicación:</strong> ${e.location}
                </div>
            </div>
            
            <div class="vehicle-description">
                <h4>Descripción</h4>
                <p>${e.description||"Sin descripción disponible."}</p>
            </div>
        </div>
        
        <div class="contact-seller">
            <h4>Contactar al Vendedor</h4>
            <div class="contact-info">
                <div class="contact-item">
                    <span>📧</span>
                    <span>${e.sellerEmail||"vendedor@automarket.com"}</span>
                </div>
                <div class="contact-item">
                    <span>📞</span>
                    <span>${e.sellerPhone||"+54 9 11 1234-5678"}</span>
                </div>
            </div>
            <button class="contact-btn" onclick="contactSeller('${t}')">
                💬 Contactar Vendedor
            </button>
        </div>
    `,u("vehicle-detail")}function h(){const t=document.getElementById("marketplace-feed");if(!t)return;const e=[{id:"1",title:"Polo Comfortline 2019",brand:"Volkswagen",model:"Polo",year:2019,price:15500,currency:"USD",mileage:145e3,location:"Pilar, BA",distance:"7 km",imageUrl:"/512X512.jpc.jpg",badge:"Recién publicado",badgeType:"new",paymentMethod:"both",description:"Excelente estado, único dueño, mantenimiento al día."},{id:"2",title:"Gol Trend 2018",brand:"Volkswagen",model:"Gol",year:2018,price:12500,currency:"USD",mileage:12e4,location:"Tigre, BA",distance:"15 km",imageUrl:"/512X512.jpc.jpg",badge:"Recién actualizado",badgeType:"updated",paymentMethod:"cash",description:"Buen estado general, algunos detalles menores."},{id:"3",title:"Civic EX 2020",brand:"Honda",model:"Civic",year:2020,price:25e3,currency:"USD",mileage:45e3,location:"San Isidro, BA",distance:"12 km",imageUrl:"/512X512.jpc.jpg",badge:"Recién publicado",badgeType:"new",paymentMethod:"financing",description:"Impecable, como nuevo, con garantía extendida."},{id:"4",title:"Corolla XEI 2017",brand:"Toyota",model:"Corolla",year:2017,price:18e3,currency:"USD",mileage:85e3,location:"Vicente López, BA",distance:"8 km",imageUrl:"/512X512.jpc.jpg",badge:"Recién publicado",badgeType:"new",paymentMethod:"both",description:"Excelente confiabilidad Toyota, servicio oficial."}];let o="";e.forEach((n,i)=>{o+=`
            <div class="vehicle-card" onclick="showVehicleDetail('${n.id}')">
                <img src="${n.imageUrl}" alt="${n.title}" class="vehicle-image">
                <div class="vehicle-badge ${n.badgeType}">${n.badge}</div>
                <div class="vehicle-actions" onclick="event.stopPropagation()">
                    <button class="action-btn edit-btn" onclick="editPublication('${n.id}')" title="Editar publicación">
                        ✏️
                    </button>
                    <button class="action-btn pause-btn" onclick="pausePublication('${n.id}')" title="Pausar publicación">
                        ⏸️
                    </button>
                    <button class="action-btn delete-btn" onclick="confirmDeletePublication('${n.id}')" title="Eliminar publicación">
                        🗑️
                    </button>
                </div>
                <div class="vehicle-info">
                    <div class="vehicle-price">$${n.price.toLocaleString()}</div>
                    <div class="vehicle-details">${n.title} ${n.mileage.toLocaleString()}km</div>
                    <div class="vehicle-location">
                        <span>📍</span>
                        <span>${n.location} ${n.distance}</span>
                    </div>
                </div>
            </div>
        `,(i+1)%2===0&&i<e.length-1&&(o+=`
                <div class="ad-card" onclick="showAdDetail('ad-${i}')">
                    <div class="ad-content">
                        <div class="ad-badge">PUBLICIDAD</div>
                        <div class="ad-image">📢</div>
                        <div class="ad-text">
                            <strong>Tu Anuncio Aquí</strong>
                            <p>Promociona tu negocio</p>
                        </div>
                    </div>
                </div>
            `)}),t.innerHTML=o}let r=[];const E=10,L=2;function ee(){const t=document.getElementById("gallery-input");t&&t.click()}async function te(t){const e=Array.from(t.target.files);let o=e.filter(s=>s.type.startsWith("image/")),n=e.filter(s=>s.type.startsWith("video/"));const i=r.filter(s=>s.type.startsWith("image/")).length,a=r.filter(s=>s.type.startsWith("video/")).length;i+o.length>E&&(o=o.slice(0,E-i),l(`Solo puedes seleccionar hasta ${E} fotos`)),a+n.length>L&&(n=n.slice(0,L-a),l(`Solo puedes seleccionar hasta ${L} videos`));const c=50*1024*1024,p=[];for(const s of n){if(s.size>c){l(`El video "${s.name}" es demasiado grande. Máximo 50MB.`);continue}p.push(s),ne(s).then(y=>{if(!y){l(`El video "${s.name}" es muy largo. Máximo 1 minuto.`);const b=r.indexOf(s);b>-1&&(r.splice(b,1),P(),$())}}).catch(y=>{console.warn("Could not validate video duration:",y)})}n=p,r.push(...o,...n),P(),$(),ie(o,n),t.target.value=""}function P(){const t=document.getElementById("gallery-preview");t&&(t.innerHTML="",r.forEach((e,o)=>{const n=document.createElement("div");if(n.className="gallery-item",e.type.startsWith("image/"))n.innerHTML=`
                <img src="${URL.createObjectURL(e)}" alt="Preview ${o+1}">
                <div class="gallery-item-type">📸</div>
                <div class="gallery-item-overlay">
                    <button class="gallery-item-remove" onclick="removeGalleryItem(${o})">🗑️ Eliminar</button>
                </div>
            `;else if(e.type.startsWith("video/")){const i=URL.createObjectURL(e);n.innerHTML=`
                <video src="${i}" muted preload="metadata" playsinline>
                    <source src="${i}" type="${e.type}">
                    Tu navegador no soporta videos HTML5.
                </video>
                <div class="gallery-item-type">🎥</div>
                <div class="video-info">
                    <span class="video-duration">⏱️ ${Math.round(e.size/1024/1024*10)/10}MB</span>
                </div>
                <div class="gallery-item-overlay">
                    <button class="gallery-item-remove" onclick="removeGalleryItem(${o})">🗑️ Eliminar</button>
                </div>
            `}t.appendChild(n)}))}function oe(t){r.splice(t,1),P(),$()}function $(){const t=r.filter(i=>i.type.startsWith("image/")).length,e=r.filter(i=>i.type.startsWith("video/")).length,o=document.getElementById("photo-count"),n=document.getElementById("video-count");o&&(o.textContent=t),n&&(n.textContent=e)}function ne(t){return new Promise(e=>{const o=document.createElement("video");o.preload="metadata",o.onloadedmetadata=()=>{URL.revokeObjectURL(o.src);const n=o.duration<=60;e(n)},o.onerror=()=>{URL.revokeObjectURL(o.src),e(!0)},o.src=URL.createObjectURL(t)})}function ie(t,e){if(t.length>0||e.length>0){let o=`Archivos agregados:
`;t.forEach(n=>{const i=Math.round(n.size/1024/1024*100)/100;o+=`📸 ${n.name} (${i}MB)
`}),e.forEach(n=>{const i=Math.round(n.size/1024/1024*100)/100;o+=`🎥 ${n.name} (${i}MB)
`}),m(`${t.length} foto(s) y ${e.length} video(s) agregados correctamente`)}}function ae(){const t=document.getElementById("gallery-input");t&&t.addEventListener("change",te)}function se(){const t=document.getElementById("publish-vehicle-form");t&&t.addEventListener("submit",A)}async function A(t){if(t.preventDefault(),!g){l("Debes iniciar sesión para publicar vehículos"),u("login");return}if(r.length===0){l("Debes seleccionar al menos una foto del vehículo");return}const e=new FormData(t.target),o={title:e.get("title"),brand:e.get("brand"),model:e.get("model"),year:parseInt(e.get("year")),mileage:parseInt(e.get("mileage")),price:parseFloat(e.get("price")),currency:e.get("currency"),location:e.get("location"),description:e.get("description"),sellerId:v.uid,sellerEmail:v.email,sellerPhone:"+54 9 11 1234-5678",createdAt:new Date,status:"active"};try{const n=await q(o,r);console.log("Vehicle published with ID:",n),m("¡Vehículo publicado exitosamente!"),u("explore"),document.getElementById("publish-vehicle-form").reset(),r=[],P(),$(),h()}catch(n){console.error("Error publishing vehicle:",n),l("Error al publicar el vehículo. Intenta nuevamente.")}}function le(t){const e=d.find(o=>o.id===t);e&&ce(t,e)}function ce(t,e){const o=document.createElement("div");o.className="modal-overlay",o.innerHTML=`
        <div class="modal-content edit-modal">
            <div class="modal-header">
                <h3>✏️ Editar Publicación</h3>
                <button class="modal-close" onclick="closeModal(this)">×</button>
            </div>
            <div class="modal-body">
                <p><strong>Editando:</strong> "${e.title}"</p>
                
                <form id="edit-vehicle-form" class="edit-form">
                    <div class="form-group">
                        <label class="form-label">Título de la Publicación</label>
                        <input type="text" class="form-input" name="title" value="${e.title}" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Precio</label>
                            <input type="number" class="form-input" name="price" value="${e.price}" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Moneda</label>
                            <select class="form-select" name="currency" required>
                                <option value="USD" ${e.currency==="USD"?"selected":""}>🇺🇸 USD (Dólar Americano)</option>
                                <option value="USDC" ${e.currency==="USDC"?"selected":""}>💎 USDC (USD Coin)</option>
                                <option value="USDT" ${e.currency==="USDT"?"selected":""}>💎 USDT (Tether)</option>
                                <option value="ARS" ${e.currency==="ARS"?"selected":""}>🇦🇷 ARS (Peso Argentino)</option>
                                <option value="MXN" ${e.currency==="MXN"?"selected":""}>🇲🇽 MXN (Peso Mexicano)</option>
                                <option value="COP" ${e.currency==="COP"?"selected":""}>🇨🇴 COP (Peso Colombiano)</option>
                                <option value="BRL" ${e.currency==="BRL"?"selected":""}>🇧🇷 BRL (Real Brasileño)</option>
                                <option value="CLP" ${e.currency==="CLP"?"selected":""}>🇨🇱 CLP (Peso Chileno)</option>
                                <option value="PEN" ${e.currency==="PEN"?"selected":""}>🇵🇪 PEN (Sol Peruano)</option>
                                <option value="UYU" ${e.currency==="UYU"?"selected":""}>🇺🇾 UYU (Peso Uruguayo)</option>
                                <option value="PYG" ${e.currency==="PYG"?"selected":""}>🇵🇾 PYG (Guaraní Paraguayo)</option>
                                <option value="BOB" ${e.currency==="BOB"?"selected":""}>🇧🇴 BOB (Boliviano)</option>
                                <option value="VES" ${e.currency==="VES"?"selected":""}>🇻🇪 VES (Bolívar Venezolano)</option>
                                <option value="GTQ" ${e.currency==="GTQ"?"selected":""}>🇬🇹 GTQ (Quetzal Guatemalteco)</option>
                                <option value="HNL" ${e.currency==="HNL"?"selected":""}>🇭🇳 HNL (Lempira Hondureño)</option>
                                <option value="SVC" ${e.currency==="SVC"?"selected":""}>🇸🇻 SVC (Colón Salvadoreño)</option>
                                <option value="NIO" ${e.currency==="NIO"?"selected":""}>🇳🇮 NIO (Córdoba Nicaragüense)</option>
                                <option value="CRC" ${e.currency==="CRC"?"selected":""}>🇨🇷 CRC (Colón Costarricense)</option>
                                <option value="PAB" ${e.currency==="PAB"?"selected":""}>🇵🇦 PAB (Balboa Panameño)</option>
                                <option value="CUP" ${e.currency==="CUP"?"selected":""}>🇨🇺 CUP (Peso Cubano)</option>
                                <option value="DOP" ${e.currency==="DOP"?"selected":""}>🇩🇴 DOP (Peso Dominicano)</option>
                                <option value="HTG" ${e.currency==="HTG"?"selected":""}>🇭🇹 HTG (Gourde Haitiano)</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Ubicación</label>
                        <input type="text" class="form-input" name="location" value="${e.location}" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Kilometraje</label>
                        <input type="number" class="form-input" name="mileage" value="${e.mileage}" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Descripción</label>
                        <textarea class="form-textarea" name="description" rows="4" placeholder="Describe el estado del vehículo...">${e.description||""}</textarea>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Modalidad de Pago</label>
                        <select class="form-select" name="paymentMethod">
                            <option value="cash" ${e.paymentMethod==="cash"?"selected":""}>💵 Efectivo</option>
                            <option value="transfer" ${e.paymentMethod==="transfer"?"selected":""}>🏦 Transferencia</option>
                            <option value="financing" ${e.paymentMethod==="financing"?"selected":""}>🏧 Financiación</option>
                            <option value="both" ${e.paymentMethod==="both"?"selected":""}>💰 Efectivo o Financiación</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-actions">
                <button class="btn btn-secondary" onclick="closeModal(this)">Cancelar</button>
                <button class="btn btn-primary" onclick="savePublicationChanges('${t}')">💾 Guardar Cambios</button>
            </div>
        </div>
    `,document.body.appendChild(o)}function re(t){const e=document.getElementById("edit-vehicle-form");if(!e)return;const o=new FormData(e),n=d.find(a=>a.id===t);if(!n)return;n.title=o.get("title"),n.price=parseFloat(o.get("price")),n.currency=o.get("currency"),n.location=o.get("location"),n.mileage=parseInt(o.get("mileage")),n.description=o.get("description"),n.paymentMethod=o.get("paymentMethod"),n.updatedAt=new Date,n.badge="Recién actualizado",n.badgeType="updated";const i=document.querySelector(".modal-overlay");f(i.querySelector(".modal-close")),m("Publicación actualizada exitosamente"),h(),console.log("Publication updated:",t,n)}function de(t){const e=d.find(o=>o.id===t);e&&ve("Pausar Publicación",`¿Estás seguro de que querés pausar la publicación de "${e.title}"?`,"Pausar","Cancelar",()=>{e.status="paused",e.pausedAt=new Date,m("Publicación pausada exitosamente"),h(),console.log("Publication paused:",t)})}function ue(t){const e=d.find(o=>o.id===t);e&&pe(t,e.title)}function pe(t,e){const o=document.createElement("div");o.className="modal-overlay",o.innerHTML=`
        <div class="modal-content delete-modal">
            <div class="modal-header">
                <h3>🗑️ Eliminar Publicación</h3>
                <button class="modal-close" onclick="closeModal(this)">×</button>
            </div>
            <div class="modal-body">
                <p><strong>¿Estás seguro de que querés eliminar esta publicación?</strong></p>
                <p class="vehicle-title">"${e}"</p>
                
                <div class="delete-reasons">
                    <h4>Motivo de eliminación:</h4>
                    <div class="reason-options">
                        <label class="reason-option">
                            <input type="radio" name="deleteReason" value="sold">
                            <span>✅ Vehículo vendido</span>
                        </label>
                        <label class="reason-option">
                            <input type="radio" name="deleteReason" value="changed_mind">
                            <span>🤔 Me arrepentí de vender</span>
                        </label>
                        <label class="reason-option">
                            <input type="radio" name="deleteReason" value="price_change">
                            <span>💰 Voy a cambiar el precio (editaré la publicación)</span>
                        </label>
                        <label class="reason-option">
                            <input type="radio" name="deleteReason" value="other">
                            <span>📝 Otro motivo</span>
                        </label>
                    </div>
                    
                    <div class="custom-reason" style="display: none;">
                        <textarea placeholder="Explica tu motivo..." maxlength="200"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-actions">
                <button class="btn btn-secondary" onclick="closeModal(this)">Cancelar</button>
                <button class="btn btn-danger" onclick="deletePublication('${t}')">Eliminar Publicación</button>
            </div>
        </div>
    `,document.body.appendChild(o);const n=o.querySelectorAll('input[name="deleteReason"]'),i=o.querySelector(".custom-reason");n.forEach(a=>{a.addEventListener("change",()=>{i.style.display=a.value==="other"?"block":"none"})})}function me(t){const e=document.querySelector(".modal-overlay"),o=e.querySelector('input[name="deleteReason"]:checked'),n=e.querySelector(".custom-reason textarea");if(!o){l("Por favor selecciona un motivo para eliminar la publicación");return}const a=o.value==="other"?n.value:o.nextElementSibling.textContent,c=d.findIndex(p=>p.id===t);c>-1&&d.splice(c,1),f(e.querySelector(".modal-close")),m("Publicación eliminada exitosamente"),h(),console.log("Publication deleted:",t,"Reason:",a)}function ve(t,e,o,n,i){const a=document.createElement("div");a.className="modal-overlay",a.innerHTML=`
        <div class="modal-content">
            <div class="modal-header">
                <h3>${t}</h3>
                <button class="modal-close" onclick="closeModal(this)">×</button>
            </div>
            <div class="modal-body">
                <p>${e}</p>
            </div>
            <div class="modal-actions">
                <button class="btn btn-secondary" onclick="closeModal(this)">${n}</button>
                <button class="btn btn-primary" onclick="confirmAction()">${o}</button>
            </div>
        </div>
    `,document.body.appendChild(a),a.confirmAction=i,window.confirmAction=()=>{i(),f(a.querySelector(".modal-close")),window.confirmAction=null}}function f(t){const e=t.closest(".modal-overlay");e&&e.remove()}window.showSection=u;window.viewVehicle=Z;window.toggleFilters=J;window.openGallery=ee;window.removeGalleryItem=oe;window.handlePublishVehicle=A;window.editPublication=le;window.savePublicationChanges=re;window.pausePublication=de;window.confirmDeletePublication=ue;window.deletePublication=me;window.closeModal=f;function k(){document.getElementById("advertiser-login").style.display="flex",document.getElementById("ad-creation-form").style.display="none"}function ge(){document.getElementById("advertiser-login").style.display="none",document.getElementById("ad-creation-form").style.display="block"}function fe(){const t=document.getElementById("banner-input");t&&t.click()}function ye(t){const e=document.getElementById(`plan-${t}`);e&&(e.checked=!0)}function he(t){t.preventDefault();const e=new FormData(t.target),o={email:e.get("email"),phone:e.get("phone"),loginTime:new Date};localStorage.setItem("advertiserData",JSON.stringify(o)),ge();const n=document.querySelector('input[name="contactEmail"]'),i=document.querySelector('input[name="contactPhone"]');n&&(n.value=o.email),i&&(i.value=o.phone),console.log("Advertiser logged in:",o)}function be(t){t.preventDefault();const e=new FormData(t.target),o=e.get("plan"),n=document.getElementById("banner-input").files[0],i={id:Date.now().toString(),companyName:e.get("companyName"),businessType:e.get("businessType"),contactEmail:e.get("contactEmail"),contactPhone:e.get("contactPhone"),adTitle:e.get("adTitle"),adDescription:e.get("adDescription"),plan:o,price:o==="basic"?3:30,currency:"USD",bannerFile:n,createdAt:new Date,status:"pending_payment"};we(i),console.log("Ad created:",i)}function we(t){const e=document.createElement("div");e.className="modal-overlay",e.innerHTML=`
        <div class="modal-content payment-modal">
            <div class="modal-header">
                <h3>💳 Procesar Pago</h3>
                <button class="modal-close" onclick="closeModal(this)">×</button>
            </div>
            <div class="modal-body">
                <div class="payment-summary">
                    <h4>Resumen del Anuncio</h4>
                    <p><strong>Empresa:</strong> ${t.companyName}</p>
                    <p><strong>Plan:</strong> ${t.plan==="basic"?"Básico":"Premium"}</p>
                    <p><strong>Precio:</strong> $${t.price} USD</p>
                    <p><strong>Título:</strong> ${t.adTitle}</p>
                </div>
                
                <div class="payment-methods">
                    <h4>Métodos de Pago Disponibles</h4>
                    <div class="payment-options">
                        <button class="payment-btn" onclick="processPayment('${t.id}', 'visa')">
                            💳 Visa/Mastercard
                        </button>
                        <button class="payment-btn" onclick="processPayment('${t.id}', 'paypal')">
                            🅿️ PayPal
                        </button>
                        <button class="payment-btn" onclick="processPayment('${t.id}', 'crypto')">
                            ₿ USDC/USDT
                        </button>
                        <button class="payment-btn" onclick="processPayment('${t.id}', 'bank')">
                            🏦 Transferencia Bancaria
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `,document.body.appendChild(e)}function Pe(t,e){const o=document.querySelector(".modal-overlay");f(o.querySelector(".modal-close")),m("¡Pago procesado exitosamente! Tu anuncio será publicado en breve."),document.getElementById("advertiser-login-form").reset(),document.getElementById("create-ad-form").reset(),k(),console.log(`Payment processed for ad ${t} with method: ${e}`)}function $e(){const t=document.getElementById("banner-input");t&&t.addEventListener("change",e=>{const o=e.target.files[0];if(o){const n=document.getElementById("banner-preview");n&&(n.innerHTML=`<img src="${URL.createObjectURL(o)}" alt="Banner Preview">`)}})}function Ee(){const t=document.getElementById("advertiser-login-form"),e=document.getElementById("create-ad-form");t&&t.addEventListener("submit",he),e&&e.addEventListener("submit",be),$e()}window.showAdvertiserLogin=k;window.openBannerUpload=fe;window.selectPlan=ye;window.processPayment=Pe;window.closeModal=f;async function V(t,e){try{const o=firebase.storage(),n=[];return e.forEach((a,c)=>{const p=`${a.type.startsWith("image/")?"photo":"video"}_${c+1}_${Date.now()}`,y=o.ref(`vehicles/${t}/gallery/${p}`).put(a).then(b=>b.ref.getDownloadURL());n.push(y)}),await Promise.all(n)}catch(o){throw console.error("Error uploading gallery:",o),o}}async function Le(t,e){try{const o=firebase.storage(),n=`banner_${Date.now()}.${e.name.split(".").pop()}`;return await(await o.ref(`advertisements/${t}/banner_${n}`).put(e)).ref.getDownloadURL()}catch(o){throw console.error("Error uploading banner:",o),o}}async function Se(t,e){try{const o=firebase.storage(),n=e.map(i=>o.refFromURL(i).delete());await Promise.all(n)}catch(o){throw console.error("Error deleting gallery:",o),o}}async function q(t,e){try{const n=await firebase.firestore().collection("vehicles").add({...t,sellerId:v.uid,createdAt:firebase.firestore.FieldValue.serverTimestamp(),status:"active"});if(e&&e.length>0){const i=await V(n.id,e);await n.update({gallery:i})}return n.id}catch(o){throw console.error("Error publishing vehicle:",o),o}}window.uploadVehicleGallery=V;window.uploadAdvertisementBanner=Le;window.deleteVehicleGallery=Se;window.publishVehicleWithStorage=q;window.handleSignOut=K;window.showLoginForm=R;window.handleLogin=D;window.handleRegister=U;window.showLogin=R;window.showRegister=I;window.showTerms=X;window.acceptTerms=Y;window.toggleMenu=Q;window.closeMenu=T;
